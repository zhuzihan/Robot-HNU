#MotoDrive

```
        void initPin(int IN3_1, int IN3_2, int IN4_1, int IN4_2);
        void initMoto(int Hz);
        void setMoto(int side, int PWM);
        void RUN(int ls, int rs);
        void setCoefficient(int coefficient);
```